from django.shortcuts import render,redirect
from .models import Student
# Create your views here.


from django.db.models import Sum

from .utils import send_mail_to_client , send_email_with_attachment
from django.conf import settings


def send_email(request):
    subject = "thisnjv"
    message = "bjkifjkdn;ml"
    recipient_list = ["sherazakram2005@gmail.com"]
    file_path = f"{settings.BASE_DIR}/invoice.pdf"
    send_email_with_attachment(subject , message , recipient_list , file_path)
    return redirect('/')



def home(request):
    std = Student.objects.all()
    grand_total = Student.objects.aggregate(total=Sum('roll'))
    return render(request, "std/home.html", {'std': std, 'grand_total': grand_total})

# def home(request):

#     std=Student.objects.all() 

#     return render(request, "std/home.html", {'std':std})


def std_add(request):
    
    if request.method=='POST':
        print("Added")
        stds_roll = request.POST.get("std_roll")
        stds_name = request.POST.get("std_name")
        stds_email = request.POST.get("std_email")
        stds_address = request.POST.get("std_address")
        stds_phone = request.POST.get("std_phone")

        s=Student()
        s.roll=stds_roll
        s.name=stds_name
        s.email=stds_email
        s.address=stds_address
        s.phone=stds_phone
    
        s.save()


    return render(request, "std/add_std.html", {})

def delete_std(request, roll: int):
    s = Student.objects.get(pk=roll)
    s.delete()

    return redirect("/std/home")

def update_std(request, roll: int):
    std=Student.objects.get(pk=roll)
    return render(request,"std/update_std.html",{'std':std})

def do_update_std(request, roll: int):
    std_roll=request.POST.get("std_roll")
    std_name=request.POST.get("std_name")
    std_email=request.POST.get("std_email")
    std_address=request.POST.get("std_address")
    std_phone=request.POST.get("std_phone")

    std=Student.objects.get(pk=roll)

    std.roll=std_roll
    std.name=std_name
    std.email=std_email
    std.address=std_address
    std.phone=std_phone
    std.save()

    return redirect("/std/home")
