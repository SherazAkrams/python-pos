# from django.contrib import admin
from django.urls import path
from .views import *

urlpatterns = [
    # path('admin/', admin.site.urls),
    path("" , home),
    path("home/", home),
    path("add_std/", std_add),
    path("delete_std/<int:roll>", delete_std),
    path("update_std/<int:roll>", update_std),
    path("do_update_std/<int:roll>", do_update_std),
    path('send-email/', send_email, name='send_email'),

]
